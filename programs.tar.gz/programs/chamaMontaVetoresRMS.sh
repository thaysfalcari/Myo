#!/bin/bash

##################################################################################
#                                                                                #
# Esse shell chama o programa montaVetores.m passando como argumento             #
# todos os arquivos gerados pelo programa chamaMontaMatrizDeTxtParaAscii.sh,     #
# os quais receberam o nome emgAmostra_01_janela_01_tamanho_128.ascii            #
# para os vetores com 128 amostras e emgAmostra_01_janela_01_tamanho_256.ascii   #
# para os vetores com 256 amostras, para que seja calculado o  valor RMS de      #
# cada janelamento, resultando em um arquivo com apenas um vetor de 8 posições.  #
# Os arquivos gerados por este programa recebem o nome:                          #
#              emgAmostra_01_janela_01_tamanho_128_VetorRMS.ascii                #
#                                     ou                                         #
#              emgAmostra_01_janela_01_tamanho_256_VetorRMS.ascii                #
#                                                                                #
##################################################################################

for suj in *
do
    cd $suj
    echo Entrou na pasta $suj
    for dir in *
    do
	cd $dir
	echo Entrou na pasta $dir
	for arq in *8.ascii
	do
	    /media/user/THAYS/mestrado/programas_6_Gestos/montaVetores.m $arq
	    #sleep 1
	done
	ls *8_Vetor* | wc -l
	for arq in *6.ascii
	do
	    /media/user/THAYS/mestrado/programas_6_Gestos/montaVetores.m $arq
	    #sleep 1
	done
	ls *6_Vetor* | wc -l
	cd ..
    done
    cd ..
done
