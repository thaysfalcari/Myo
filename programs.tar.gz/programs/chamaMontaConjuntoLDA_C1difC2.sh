#!/bin/bash
for sujNum in 01 02 03 04 05
do
    suj="P"$sujNum""
    cd $suj
    echo Entrou na pasta $suj

    for dir in *
    do
	cd $dir
	echo Entrou na pasta $dir

	/media/user/THAYS/mestrado/programas_6_Gestos/scriptLDA_C1difC2.m conjuntoTreinoLDA_128.ascii rotulos_PCA_LDA_128_UmContraTodos.ascii conjuntoTreino_128.ascii rotulos_PCA_LDA_128_UmContraTodos_qtdeC1eqC2.ascii conjuntoTeste_128.ascii rotulos_PCA_LDA_128_UmContraTodos.ascii 128

	/media/user/THAYS/mestrado/programas_6_Gestos/scriptLDA_C1difC2.m conjuntoTreinoLDA_256.ascii rotulos_PCA_LDA_256_UmContraTodos.ascii conjuntoTreino_256.ascii rotulos_PCA_LDA_256_UmContraTodos_qtdeC1eqC2.ascii conjuntoTeste_256.ascii rotulos_PCA_LDA_256_UmContraTodos.ascii 256 

	cd ..
    done
    cd ..
done
