#! /usr/bin/octave -qf
% Como argumento de linha de comando,
% deve ser dado o nome de um arquivo que tenha
% números separados por espaços.

arg_list = argv();
nomeArqDados = arg_list{ 1 };
nomeSemExtensao = strrep ( nomeArqDados, ".ascii", "" );
dados = dlmread( nomeArqDados, " ", 0, 0 );
numLinhas = size( dados, 1 );
vetorRMS = zeros( 1, 8 ) ;
somaQuadrados = 0;
numColunas = 8;
rms = 0;
for iColuna = 1:numColunas
  for iLinha = 1:numLinhas
    %Calcula a soma dos quadrados dos elementos de cada coluna
    elemento = dados( iLinha, iColuna );
    somaQuadrados = somaQuadrados + elemento^2;
  endfor 
  %calcula o valor rms de cada coluna
  rms = sqrt(somaQuadrados/numLinhas);
  vetorRMS(iColuna) = rms;
  rms = 0;
  somaQuadrados = 0;
endfor
nomeArq = [ nomeSemExtensao, "_VetorRMS.ascii"];
save("-ascii", nomeArq, "vetorRMS" );
