#!/bin/bash

###########################################################################
# Este programa passa como argumento o arquivo Amostra0X.txt ( que        #
# contém 12.5s de dados coletados pela Myo que implica em 2500 amostras.) #
# para realizar o separação desse arquivos em janelas menores de dados    #
# que neste caso foram escolhidas duas janelas: 128 (0.64s) e 256 (1.28s) #
###########################################################################

for suj in *
do
    cd $suj
    echo Entrou na pasta $suj
    for dir in *
    do
	cd $dir
	echo Entrou na pasta $dir
	for arq in emg*.txt
	do
	    echo Encontrou o arquivo $arq
	    /media/user/THAYS/mestrado/programas_6_Gestos/montaMatrizDeTxtParaAscii.m $arq 256
	    #sleep 1
	    /media/user/THAYS/mestrado/programas_6_Gestos/montaMatrizDeTxtParaAscii.m $arq 128
	    #sleep 1
	done
	cd ..
    done
    cd ..
done
