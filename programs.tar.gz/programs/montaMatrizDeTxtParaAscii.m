#! /usr/bin/octave -qf
% Como argumento de linha de comando,
% deve ser dado o nome de um arquivo que tenha
% números separados por espaço e o tamanho da
% janela.

arg_list = argv();
nomeArqDados = arg_list{ 1 };
dados = dlmread( nomeArqDados, " ", 0, 0 );
tamJanelas = str2num( arg_list{ 2 } );
numLinhas = size( dados, 1 );
resto = rem( numLinhas, tamJanelas );
numJanelas = floor( numLinhas / tamJanelas );
linhaInicialDaJanela = floor( resto / 2 );
for indJanela = 1:numJanelas
  linhaFinalDaJanela = linhaInicialDaJanela + tamJanelas - 1;
  janelaDados = dados( linhaInicialDaJanela:linhaFinalDaJanela, : );
  nomeSemExtensao = strrep( nomeArqDados, ".txt", "" );
  nomeCompletoArq = [ nomeSemExtensao, "_janela_", sprintf( "%02d", indJanela ), "_tamanho_", num2str( tamJanelas ), ".ascii" ];
  save( "-ascii", nomeCompletoArq, "janelaDados" );
  linhaInicialDaJanela += tamJanelas;
endfor
