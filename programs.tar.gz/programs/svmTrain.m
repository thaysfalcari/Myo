clc
clear all
close all

pessoa = { 'P01', 'P02', 'P03', 'P04', 'P05' }
tamanhoPessoa = size( pessoa, 2 )
gesto = { 'clenching', 'pointing', 'relaxing', 'spreading', 'waveIn', 'waveOut' }
tamanhoGestos = size( gesto, 2 )
for p = 1:tamanhoPessoa
    pwd
    cd ( pessoa{ p } )
    
    for g = 1:tamanhoGestos
        pwd
        cd ( gesto{ g } )
        
        vetoresEntrada_128 = load( 'conjuntoTreino_128.ascii' );
        vetoresTeste_128 = load( 'conjuntoTeste_128.ascii' );
        rotulosTreino_128 = load( 'rotulosTreino_128.txt' );
        rotulosTeste_128 = load( 'rotulosTeste_128.txt' );
        vetoresEntrada_256 = load( 'conjuntoTreino_256.ascii' );
        vetoresTeste_256 = load( 'conjuntoTeste_256.ascii' );
        rotulosTreino_256 = load( 'rotulosTreino_256.txt' );
        rotulosTeste_256 = load( 'rotulosTeste_256.txt' );

        kernels = { 'linear', 'poly', 'rbf' }
        tamanhoKernel = size( kernels, 2 )

        for k = 1:tamanhoKernel
            
            SVMModel_128{ k } = fitcsvm( vetoresEntrada_128, rotulosTreino_128, 'KernelFunction', kernels{ k }, 'BoxConstraint',Inf,'ClassNames',[-1,1]);
            SVMModel_256{ k } = fitcsvm( vetoresEntrada_256, rotulosTreino_256, 'KernelFunction', kernels{ k }, 'BoxConstraint',Inf,'ClassNames',[-1,1]);

            %load 'SVMModel'
            %    emgData = load('emgData.ascii');
            %    montaVetores;
            %    emgVetorRMS = load('emgData_VetorRMS.ascii');

            %%% Calculo propor��o de acertos para janelas de 128 amostras
             [ classe, scores] = predict( SVMModel_128{ k }, vetoresEntrada_128 );
               % classe
                matrizTreino_128 = [ rotulosTreino_128 , classe ];
                acertosTreino_128 = 0;
                for i = 1:size( matrizTreino_128, 1 );
                    elemento1 = matrizTreino_128( i , 1 );
                    elemento2 = matrizTreino_128( i , 2 );
                    if ( elemento1 == elemento2 )
                       acertosTreino_128 = acertosTreino_128 + 1 ;
                    end
                end

                [ classe, scores] = predict( SVMModel_128{ k }, vetoresTeste_128 );
                %classe
                matrizTeste_128 = [ rotulosTeste_128 , classe ];
                acertosTeste_128 = 0;
                for i = 1:size( matrizTeste_128, 1 )
                    elemento1 = matrizTeste_128( i , 1 );
                    elemento2 = matrizTeste_128( i , 2 );
                    if ( elemento1 == elemento2 );
                       acertosTeste_128 = acertosTeste_128 + 1; 
                    end
                end

            %%% Calculo de propor��o acertos treino para janelas de 256 amostras	
                [ classe, scores] = predict( SVMModel_256{ k }, vetoresEntrada_256 );
               % classe
                matrizTreino_256 = [ rotulosTreino_256 , classe ];
                acertosTreino_256 = 0;
                for i = 1:size( matrizTreino_256, 1 );
                    elemento1 = matrizTreino_256( i , 1 );
                    elemento2 = matrizTreino_256( i , 2 );
                    if ( elemento1 == elemento2 )
                       acertosTreino_256 = acertosTreino_256 + 1 ;
                    end
                end

                [ classe, scores] = predict( SVMModel_256{ k }, vetoresTeste_256 );
                %classe
                matrizTeste_256 = [ rotulosTeste_256 , classe ];
                acertosTeste_256 = 0;
                for i = 1:size( matrizTeste_256, 1 )
                    elemento1 = matrizTeste_256( i , 1 );
                    elemento2 = matrizTeste_256( i , 2 );
                    if ( elemento1 == elemento2 );
                       acertosTeste_256 = acertosTeste_256 + 1; 
                    end
                end

            totalAcertos_Treino_128( k ) = ( acertosTreino_128 / size( matrizTreino_128, 1)) * 100;
            totalAcertos_Teste_128( k ) = ( acertosTeste_128 / size( matrizTeste_128, 1)) * 100;
            totalAcertos_Treino_256( k ) = ( acertosTreino_256 / size( matrizTreino_256, 1)) * 100;
            totalAcertos_Teste_256( k ) = ( acertosTeste_256 / size( matrizTeste_256, 1)) * 100;
			
            %vetAcertos{ k } = {' ' kernels{ k } ' ';' ' 'Treino' 'Teste'; '128' totalAcertos_Treino_128 totalAcertos_Teste_128; '256' totalAcertos_Treino_256 totalAcertos_Teste_256 };
            %nomeArqSave = [ 'SVMModel_128_' kernels{ k } ];
            %xlswrite( nomeArqSave, vetAcertos{ k } );
            %save( nomeArqSave, '', '-ascii' )
       

        end	
        nomeArqSave = [ 'SVMModel_' gesto{ g } ];
        vetAcertos = [ totalAcertos_Treino_128; totalAcertos_Teste_128; totalAcertos_Treino_256; totalAcertos_Teste_256 ]
        xlswrite( nomeArqSave, vetAcertos );
        
        cd ..
        %cd ..
        cd arqSVM 
        
        [ melhorSVM_128, indice_128 ] = max( totalAcertos_Teste_128 )
        nomeSVMModel_128 = [ pessoa{ p } 'SVMModel_128_' gesto{ g } '_' kernels{ indice_128 } ]
        saveSVM_128 = SVMModel_128{ indice_128 }
        save( nomeSVMModel_128, 'saveSVM_128' )
        
        [ melhorSVM_256, indice_256 ] = max( totalAcertos_Teste_256 )
        nomeSVMModel_256 = [ pessoa{ p } 'SVMModel_256_' gesto{ g } '_' kernels{ indice_256 } ]
        saveSVM_256 = SVMModel_256{ indice_256 }
        save( nomeSVMModel_256, 'saveSVM_256' )   
        
        pwd
        cd ..
        pwd
        %cd ( pessoa{ p } )
        %pwd
        
    end 
    cd ..
end
