#!/bin/bash
for suj in *
do
    cd $suj
    echo Entrou na pasta $suj

    for dir in *
    do
	cd $dir
	echo Entrou no diretorio $dir
	touch arqAuxAmostraTreino_256.ascii
	touch arqAuxAmostraTreino_128.ascii

	for numTreino in 03 06 07 08 09 11 16 17 18 20
	do
	    amostraTreino_256=$(ls -1 emgAmostra_"$numTreino"*256_VetorRMS.ascii)
	    cat arqAuxAmostraTreino_256.ascii $amostraTreino_256 > tmp
	    mv tmp arqAuxAmostraTreino_256.ascii

	    amostraTreino_128=$(ls -1 emgAmostra_"$numTreino"*128_VetorRMS.ascii)
	    cat arqAuxAmostraTreino_128.ascii $amostraTreino_128 > tmp
	    mv tmp arqAuxAmostraTreino_128.ascii

	done
	
	mv arqAuxAmostraTreino_256.ascii VetRMS_Treino_256_semRotulos.ascii
	sort -R VetRMS_Treino_256_semRotulos.ascii > VetRMS_Treino_256_semRotulos_embaralhado.ascii
	echo Numero de linhas 256:
	wc -l VetRMS_Treino_256_semRotulos_embaralhado.ascii | cut -d" " -f1
	head -n 18 VetRMS_Treino_256_semRotulos_embaralhado.ascii > treino_18_primeirosVetRMS_256_semRotulos_embaralhado.ascii
	echo Numero de linhas 18 primeiros:
	wc -l treino_18_primeirosVetRMS_256_semRotulos_embaralhado.ascii | cut -d" " -f1

	mv arqAuxAmostraTreino_128.ascii VetRMS_Treino_128_semRotulos.ascii
	sort -R VetRMS_Treino_128_semRotulos.ascii > VetRMS_Treino_128_semRotulos_embaralhado.ascii
	echo Numero de linhas 128:
	wc -l VetRMS_Treino_128_semRotulos_embaralhado.ascii | cut -d" " -f1
	head -n 38 VetRMS_Treino_128_semRotulos_embaralhado.ascii > treino_38_primeirosVetRMS_128_semRotulos_embaralhado.ascii
	echo Numero de linhas 38 primeiros:
	wc -l treino_38_primeirosVetRMS_128_semRotulos_embaralhado.ascii | cut -d" " -f1

	

	touch arqAuxAmostraTeste_256.ascii
	touch arqAuxAmostraTeste_128.ascii
	
	for numTeste in 01 02 04 05 10 12 13 14 15 19
	do
	    amostraTeste_256=$(ls -1 emgAmostra_"$numTeste"*256_VetorRMS.ascii)
	    cat arqAuxAmostraTeste_256.ascii $amostraTeste_256 > tmp
	    mv tmp arqAuxAmostraTeste_256.ascii

	    amostraTeste_128=$(ls -1 emgAmostra_"$numTeste"*128_VetorRMS.ascii)
	    cat arqAuxAmostraTeste_128.ascii $amostraTeste_128 > tmp
	    mv tmp arqAuxAmostraTeste_128.ascii

	done

	mv arqAuxAmostraTeste_256.ascii VetRMS_Teste_256_semRotulos.ascii 
	sort -R VetRMS_Teste_256_semRotulos.ascii > VetRMS_Teste_256_semRotulos_embaralhado.ascii
	echo Numero de linhas 256:
	wc -l VetRMS_Teste_256_semRotulos_embaralhado.ascii | cut -d" " -f1

	mv arqAuxAmostraTeste_128.ascii  VetRMS_Teste_128_semRotulos.ascii
	sort -R VetRMS_Teste_128_semRotulos.ascii > VetRMS_Teste_128_semRotulos_embaralhado.ascii
	echo Numero de linhas 128:
	wc -l VetRMS_Teste_128_semRotulos_embaralhado.ascii | cut -d" " -f1

	cd ..
    done
    cd ..
done
