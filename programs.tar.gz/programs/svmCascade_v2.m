clc 
clear all 
close all
% Carrega a SVM treinada
SVMModel_256_waveIn_linear = load ('SVMModel_256_waveIn_linear');
new = SVMModel_256_waveIn_linear;
SVMModel_256_waveOut_linear = load ('SVMModel_256_waveOut_linear');
new = SVMModel_256_waveOut_linear;
SVMModel_256_relaxing_linear = load ('SVMModel_256_relaxing_poly');
new = SVMModel_256_relaxing_linear;
SVMModel_256_spreading_rbf = load ('SVMModel_256_spreading_poly');
new = SVMModel_256_spreading_rbf;
SVMModel_256_pointing_rbf = load ('SVMModel_256_pointing_poly');
new = SVMModel_256_pointing_rbf;
SVMModel_256_clenching_rbf = load ('SVMModel_256_clenching_poly');
new = SVMModel_256_clenching_rbf;

teste = 0;
waveIn = 0;
waveOut = 0;
relaxing = 0;
spreading = 0;
pointing = 0;
clenching = 0;

waveIn = zeros( 540, 1 );
waveOut = zeros( 540, 1 );
relaxing = zeros( 540, 1 );
spreading = zeros( 540, 1);
pointing = zeros( 540, 1 );
clenching = zeros( 540, 1);

emgVetorRMS = load('todosOsVetsRMS_P02_256.ascii');
rotulosTeste_waveIn = load('rotulosTeste_waveInv2.txt');
rotulosTeste_waveOut = load('rotulosTeste_waveOutv2.txt');
rotulosTeste_relaxing = load('rotulosTeste_relaxingv2.txt');
rotulosTeste_spreading = load('rotulosTeste_spreadingv2.txt');
rotulosTeste_pointing = load('rotulosTeste_pointingv2.txt');
rotulosTeste_clenching = load('rotulosTeste_clenchingv2.txt');

countWaveIn = 0;
countWaveOut = 0;
countRelaxing = 0;
countSpreading = 0;
countPointing = 0;
countClenching = 0;
for i = 1:size(emgVetorRMS, 1)
   
    [ classe_waveIn, scores1 ] = predict( SVMModel_256_waveIn_linear, emgVetorRMS(i,:));
	countWaveIn = countWaveIn + 1;
    if (classe_waveIn == 1)
        waveIn(i) = 1;
    else
        waveIn(i) = -1;
        [ classe_waveOut, scores2 ] = predict( SVMModel_256_waveOut_linear, emgVetorRMS(i,:));
		countWaveOut = countWaveOut + 1;
        if (classe_waveOut == 1)
            waveOut(i) =  1;
        else
            waveOut(i) = -1;
            [ classe_relaxing, scores3 ] = predict( SVMModel_256_relaxing_poly, emgVetorRMS(i,:)); 
			countRelaxing = countRelaxing + 1;
            if (classe_relaxing == 1)
                relaxing(i) = 1;
            else
                relaxing(i) = -1;
                [ classe_spreading, scores4 ] = predict( SVMModel_256_spreading_poly, emgVetorRMS(i,:));
				countSpreading = countSpreading + 1;
                if (classe_spreading == 1)
                    spreading(i) = 1;
                else
                    spreading(i) = -1;
                    [ classe_pointing, scores5 ] = predict( SVMModel_256_pointing_poly, emgVetorRMS(i,:));
					countPointing = countPointing + 1;
                    if (classe_pointing == 1)
                        pointing(i) = 1;
                    else
                        pointing(i) = -1;
                        [ classe_clenching, scores6 ] = predict( SVMModel_256_clenching_poly, emgVetorRMS(i,:));
						countClenching = countClenching + 1;
                        if (classe_clenching == 1)
                            clenching(i) =  1;
                        else
                            clenching(i) = -1;
                        end
                    end
                end
            end
        end
    end    
    %Resp = [classe_waveIn , scores1; classe_waveOut , scores2; classe_relaxing , scores3; classe_spreading , scores4; classe_pointing , scores5; classe_clenching , scores6;]
end

matrizTeste_waveIn = [ rotulosTeste_waveIn , waveIn ];
    acertosTeste = 0;
    for i = 1:size( matrizTeste_waveIn, 1 )
        elemento1 = matrizTeste_waveIn( i , 1 );
        elemento2 = matrizTeste_waveIn( i , 2 );
        if ( elemento1 == elemento2 ) 
           acertosTeste = acertosTeste + 1; 
        end
    end
     totalAcertos_waveIn = ( acertosTeste / size( matrizTeste_waveIn, 1)) * 100
	 %totalAcertos_waveIn = ( acertosTeste / countWaveIn ) * 100
     
 matrizTeste_waveOut = [ rotulosTeste_waveOut , waveOut ];
    acertosTeste = 0;
    for i = 1:size( matrizTeste_waveOut, 1 )
        elemento1 = matrizTeste_waveOut( i , 1 );
        elemento2 = matrizTeste_waveOut( i , 2 );
        if ( elemento1 == elemento2 ) || (( elemento1 == -1 ) && ( elemento2 == 0 ))
           acertosTeste = acertosTeste + 1; 
        end
    end
     totalAcertos_waveOut = ( acertosTeste / size( matrizTeste_waveOut, 1)) * 100
	 %totalAcertos_waveOut = ( acertosTeste / countWaveOut ) * 100

 matrizTeste_relaxing = [ rotulosTeste_relaxing , relaxing ];
    acertosTeste = 0;
    for i = 1:size( matrizTeste_relaxing, 1 )
        elemento1 = matrizTeste_relaxing( i , 1 );
        elemento2 = matrizTeste_relaxing( i , 2 );
        if ( elemento1 == elemento2 ) || (( elemento1 == -1 ) && ( elemento2 == 0 ))
           acertosTeste = acertosTeste + 1; 
        end
    end
     totalAcertos_relaxing = ( acertosTeste / size( matrizTeste_relaxing, 1)) * 100
	 %totalAcertos_relaxing = ( acertosTeste / countRelaxing ) * 100

  matrizTeste_spreading = [ rotulosTeste_spreading , spreading ];
    acertosTeste = 0;
    for i = 1:size( matrizTeste_spreading, 1 )
        elemento1 = matrizTeste_spreading( i , 1 );
        elemento2 = matrizTeste_spreading( i , 2 );
        if ( elemento1 == elemento2 ) || (( elemento1 == -1 ) && ( elemento2 == 0 ))
           acertosTeste = acertosTeste + 1; 
        end
    end  
     totalAcertos_spreading = ( acertosTeste / size( matrizTeste_spreading, 1)) * 100
	 %totalAcertos_spreading = ( acertosTeste / countSpreading ) * 100
     
 matrizTeste_pointing = [ rotulosTeste_pointing , pointing ];
    acertosTeste = 0;
    for i = 1:size( matrizTeste_pointing, 1 )
        elemento1 = matrizTeste_pointing( i , 1 );
        elemento2 = matrizTeste_pointing( i , 2 );
        if ( elemento1 == elemento2 ) || (( elemento1 == -1 ) && ( elemento2 == 0 ))
           acertosTeste = acertosTeste + 1; 
        end
    end
     totalAcertos_pointing = ( acertosTeste / size( matrizTeste_pointing, 1)) * 100
	 %totalAcertos_pointing = ( acertosTeste / countPointing ) * 100
     
 matrizTeste_clenching = [ rotulosTeste_clenching , clenching ];
    acertosTeste = 0;
    for i = 1:size( matrizTeste_clenching, 1 )
        elemento1 = matrizTeste_clenching( i , 1 );
        elemento2 = matrizTeste_clenching( i , 2 );
        if ( elemento1 == elemento2 ) || (( elemento1 == -1 ) && ( elemento2 == 0 ))
           acertosTeste = acertosTeste + 1; 
        end
    end
     totalAcertos_clenching = ( acertosTeste / size( matrizTeste_clenching, 1)) * 100
	 %totalAcertos_clenching = ( acertosTeste / countClenching ) * 100

