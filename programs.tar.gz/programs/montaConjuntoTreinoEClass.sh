#!/bin/bash
declare -a numSujeito=("01" "02" "03" "04" "05")
for sujNum in $numSujeito
do
    suj="P"$sujNum""
    cd $suj
    echo Entrou na pasta $suj
    
    for dir in *
    do
	#touch $dir/arqAuxTreino_256_DaClasse_menosUm.ascii
	#touch $dir/arqAuxTreino_128_DaClasse_menosUm.ascii
	cp $dir/VetRMS_Treino_128_semRotulos_embaralhado.ascii $dir/arqAuxTreino_128.ascii
	cp $dir/VetRMS_Treino_256_semRotulos_embaralhado.ascii $dir/arqAuxTreino_256.ascii
	cp $dir/VetRMS_Teste_128_semRotulos_embaralhado.ascii $dir/arqAuxTeste_128.ascii
	cp $dir/VetRMS_Teste_256_semRotulos_embaralhado.ascii $dir/arqAuxTeste_256.ascii
	echo Copiou arquivos

	for dir2 in *
	do
	    echo Dir1: $dir  Dir2: $dir2
	    if [ "$dir" != "$dir2" ]; then
		echo Diretorios diferentes
		cat $dir/arqAuxTreino_128.ascii $dir2/treino_38_primeirosVetRMS_128_semRotulos_embaralhado.ascii > tmp
		mv tmp $dir/arqAuxTreino_128.ascii
		
		cat $dir/arqAuxTreino_256.ascii $dir2/treino_18_primeirosVetRMS_256_semRotulos_embaralhado.ascii > tmp
		mv tmp $dir/arqAuxTreino_256.ascii
		
		cat $dir/arqAuxTeste_128.ascii $dir2/VetRMS_Teste_128_semRotulos_embaralhado.ascii > tmp
		mv tmp $dir/arqAuxTeste_128.ascii
		
		cat $dir/arqAuxTeste_256.ascii $dir2/VetRMS_Teste_256_semRotulos_embaralhado.ascii > tmp
		mv tmp $dir/arqAuxTeste_256.ascii

		#cat $dir/arqAuxTreino_256_DaClasse_menosUm.ascii $dir2/treino_18_primeirosVetRMS_256_semRotulos_embaralhado.ascii > tmp
		#mv tmp $dir/arqAuxTreino_256_DaClasse_menosUm.ascii

		#cat $dir/arqAuxTreino_128_DaClasse_menosUm.ascii $dir2/treino_38_primeirosVetRMS_128_semRotulos_embaralhado.ascii > tmp
		#mv tmp $dir/arqAuxTreino_128_DaClasse_menosUm.ascii

	    else
		echo Diretorios iguais
	    fi
	
	done
	mv $dir/arqAuxTreino_256.ascii $dir/conjuntoTreino_256.ascii
	echo Numero linhas conjunto treino 256:
	wc -l $dir/conjuntoTreino_256.ascii | cut -d" " -f1
	#ls -1 $dir/conjuntoTreino_256.ascii |wc -l 

	mv $dir/arqAuxTreino_128.ascii $dir/conjuntoTreino_128.ascii
	echo Numero linhas conjunto treino 128:
	wc -l $dir/conjuntoTreino_128.ascii | cut -d" " -f1
	#ls -1 $dir/conjuntoTreino_128.ascii |wc -l 

	mv $dir/arqAuxTeste_256.ascii $dir/conjuntoTeste_256.ascii
	echo Numero linhas conjunto teste 256:
	wc -l $dir/conjuntoTeste_256.ascii | cut -d" " -f1
	#ls -1 $dir/conjuntoTeste_256.ascii |wc -l
	
	mv $dir/arqAuxTeste_128.ascii $dir/conjuntoTeste_128.ascii
	echo Numero linhas conjunto teste 128:
	wc -l $dir/conjuntoTeste_128.ascii | cut -d" " -f1
	#ls -1 $dir/conjuntoTeste_128.ascii |wc -l

	#mv $dir/arqAuxTreino_256_DaClasse_menosUm.ascii $dir/VetRMSTreino_256_DaClasse_menosUm.ascii
	#echo Numero de linhas 256 da classe menos um:
	#wc -l $dir/VetRMSTreino_256_DaClasse_menosUm.ascii  | cut -d" " -f1

	#mv $dir/arqAuxTreino_128_DaClasse_menosUm.ascii $dir/VetRMSTreino_128_DaClasse_menosUm.ascii
	#echo Numero de linhas 128 da classe menos um:
	#wc -l $dir/VetRMSTreino_128_DaClasse_menosUm.ascii  | cut -d" " -f1
    done
    cd ..
done
